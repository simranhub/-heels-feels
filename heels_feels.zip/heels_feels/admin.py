from django.contrib import admin
from heels_feels.models import user_data,women,men,kids,cart
# Register your models here.
admin.site.register(user_data)

admin.site.register(women)
admin.site.register(men)
admin.site.register(kids)
admin.site.register(cart)
