

$(document).ready(function(){
    $('.sidenav').sidenav();
    $('.modal').modal();
  });
  
 function show_section(x){
   if(x=="women_link"){
     document.getElementById("women").style.display="block";
     document.getElementById("men").style.display="none";
     document.getElementById("kids").style.display="none";
     document.getElementById("cart").style.display="none";
   }
   else if(x=="men_link"){
    document.getElementById("women").style.display="none";
    document.getElementById("men").style.display="block";
    document.getElementById("kids").style.display="none";
    document.getElementById("cart").style.display="none";
  }
  else if(x=="kids_link"){
   document.getElementById("women").style.display="none";
   document.getElementById("men").style.display="none";
   document.getElementById("kids").style.display="block";
   document.getElementById("cart").style.display="none";
 }else if(x=="cart_link"){
  document.getElementById("women").style.display="none";
  document.getElementById("men").style.display="none";
  document.getElementById("kids").style.display="none";
  document.getElementById("cart").style.display="block";
}
 }